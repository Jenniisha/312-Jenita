const config={
    PAGE_SIZE:5
};

export default config;
